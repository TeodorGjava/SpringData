package softuni.exam.constants;

public enum Messages {
    ;
    public static final String INVALID_COUNTRY = "Invalid country%n";
    public static final String VALID_COUNTRY_FORMAT = "Successfully imported country %s - %s%n";
}
