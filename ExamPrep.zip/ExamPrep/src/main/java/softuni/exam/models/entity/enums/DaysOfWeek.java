package softuni.exam.models.entity.enums;

public enum DaysOfWeek {
    FRIDAY, SATURDAY, SUNDAY
}
