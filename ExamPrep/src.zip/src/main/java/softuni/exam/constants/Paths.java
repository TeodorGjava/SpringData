package softuni.exam.constants;

public enum Paths {
    ; public final static String URL_COUNTRIES_JSON = "src/main/resources/files/json/countries.json" ;
}
