public enum Constants {
    ;
    final static String USER_KEY = "user";
    final static String USER_VALUE = "root";

    final static String PASSWORD_KEY = "password";
    final static String PASSWORD_VALUE = "root";

    final static String URL_JDBC = "jdbc:mysql://localhost:3306/minions_db";
    static final String NAME_COLUMN_LABEL = "name";
    static final String AGE_COLUMN_LABEL = "age";
     static final String COUNT_COLUMN_NAME = "count";

}
