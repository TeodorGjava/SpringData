package softuni.exam.models.enums;

public enum CarType {
    SUV, coupe, sport
}
