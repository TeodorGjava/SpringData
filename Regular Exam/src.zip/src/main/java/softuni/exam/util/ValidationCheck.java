package softuni.exam.util;

public interface ValidationCheck {

    <E> boolean isValid(E entity);
}
