create definer = root@localhost view with_or_without_taxes as
select `c`.`brand`                        AS `brand`,
       `c`.`model`                        AS `model`,
       sum(`e`.`price`)                   AS `sum_price`,
       round(sum((`e`.`price` * 1.2)), 2) AS `sum_price_with_taxes`
from `carbase`.`cars` `c`
         join `carbase`.`events` `e`
group by `e`.`car_id`;

